package com.csm.LibraryManagementim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagementimApplicationTests {

	@Test
	void contextLoads() {
	}

}
